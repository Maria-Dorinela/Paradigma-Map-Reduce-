import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;


public class WorkerMap extends Thread{
	
	WorkPool_Map workpool_map;
	WorkPool_Reduce workpool_reduce;
	ArrayList<String> documente = new ArrayList<String>();
	FinalSolution final_solution = new FinalSolution();
	String output;//numele fisierului de iesire
	//ArrayList<String> words;
	/**
	 * constructor implicit
	 */
	public WorkerMap(){
		
	}
	
	/**
	 * constructor cu parametri
	 */
	public WorkerMap(WorkPool_Map workpool_map,WorkPool_Reduce workpool_reduce,ArrayList<String> documente, FinalSolution final_solution,String output){
		this.documente = documente;
		this.workpool_map = workpool_map;
		this.workpool_reduce = workpool_reduce;
		this.final_solution = final_solution;
		this.output = output;
	}
	
	public void processTaskMap(TaskMap taskmap) throws IOException{
		
		//ArrayList<CuvinteAparitii> cuvinteaparitii_partial = new ArrayList<CuvinteAparitii>();
		HashMap h = new HashMap();
	
      
      //pentru aflarea numarului total de cuvinte
		ArrayList<String> total_cuvinte = new ArrayList<String>();
		
		for(int e = 0; e < taskmap.nume_s.size(); e++){
			StringTokenizer tokens = new StringTokenizer(taskmap.nume_s.get(e), " ,.-\"");
    		while(tokens.hasMoreTokens()){
    			String word = tokens.nextToken().toLowerCase();
    			total_cuvinte.add(word);
    		}
		}
		//System.out.println("Numarul total de cuvinte este: " + total_cuvinte.size());
        int pozitie = 0;
        ArrayList<String> fragmente_octeti_unul = new ArrayList<String>();;
       
        for(int i = 0; i < taskmap.nume_s.size(); i++){
        	pozitie = i;
        	if(pozitie >= taskmap.initial_position && pozitie <= taskmap.final_position){
        		fragmente_octeti_unul = new ArrayList<String>();
        		
        		StringTokenizer tokens = new StringTokenizer(taskmap.nume_s.get(i), " ,.-\"");
        		while(tokens.hasMoreTokens()){
        			String word = tokens.nextToken().toLowerCase();
        			fragmente_octeti_unul.add(word);
        		}
        	}
        }
      
        int nr_total_cuvinte = total_cuvinte.size();
        ArrayList<Double> numar_aparitii = new ArrayList<Double>();
        int nr_p = 0;
        for(int i = 0; i < fragmente_octeti_unul.size(); i++){
        	
        	for(int j = 0; j < fragmente_octeti_unul.size(); j++){
        		if(fragmente_octeti_unul.get(i).equals(fragmente_octeti_unul.get(j)))
        			nr_p += 1;
        		
        	}
        	
        	double frecventa = ((double)nr_p/(double)nr_total_cuvinte) * 100;
            double rounded = Math.floor(1000 * frecventa + 0.5) / 1000;
        	numar_aparitii.add(rounded);
        	nr_p = 0;
        }
      
        ArrayList<CuvinteAparitii> cva = new ArrayList<CuvinteAparitii>();
        for(int k = 0; k < fragmente_octeti_unul.size(); k++){
        	CuvinteAparitii ca = new CuvinteAparitii(fragmente_octeti_unul.get(k), numar_aparitii.get(k));
        	cva.add(ca);
        }
        /*System.out.println("\n++++++++++++++++++++++\n");
		System.out.println(cva);*/
		workpool_reduce.putWork(new PartialSolution(h,taskmap.nume_fisier,cva, taskmap.nume_s));
		cva.clear();
		
	}
	
	public void run(){
		
		while (true) {
			
			TaskMap tm = workpool_map.getWork();
			if (tm == null){
				break;
			}
		
			try {
				processTaskMap(tm);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//WorkerReduce
		WorkerReduce worker_reduce = new WorkerReduce(workpool_reduce, final_solution, documente, output);
		worker_reduce.start();
	}

}
