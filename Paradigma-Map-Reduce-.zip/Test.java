import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;


public class Test {
	
	public static Object o = "";
	
	static double roundTwoDecimals(double d) {
	    DecimalFormat twoDForm = new DecimalFormat("#.###");
	    return Double.valueOf(twoDForm.format(d));
	}
	
	public static void main(String[] args) {
		//verificare introducere corecta a numarului de parametri
		if(args.length == 0){
			System.out.println("Introducerea parametrilor a fost gresita. Reincercati!!");
			return;
		}
		else{
		//argumentele programului
		int NT = Integer.parseInt(args[0]);//numarul de thread-uri worker
		String file_in = args[1];//numele fisierului de intrare
		String file_out = args[2];//numele fisierului de iesire
		
		
		//salvare date din fisierul de intrare
		String first_line = "";//numele documentului DOC pentru care se dorește determinarea gradului de plagiere
		ArrayList<String> documente_de_verificat = new ArrayList<String>();//numele celor ND documente
		int nr_octeti_fragment = 0;//dimensiunea D (în octeți) a fragmentelor în care se vor impărți fișierele
		float procent = 0.0f;//pragul de similaritate
		int nr_documente = 0;//numarul ND de documente de tip text de indexat și în care se va face căutarea
		HashMap h = new HashMap();
        //citire din fisierul de intrare
        try{
            InputStream ips=new FileInputStream(file_in); 
            InputStreamReader ipsr=new InputStreamReader(ips);
            BufferedReader br=new BufferedReader(ipsr);
            String line;
            
            first_line = br.readLine();
            //System.out.println("\nFisierul principal este: " + first_line);
            
            nr_octeti_fragment = Integer.parseInt(br.readLine());
            //System.out.println("Numerul de fragmentari este: " + nr_octeti_fragment);
            
            procent = Float.parseFloat(br.readLine());
           // System.out.println("Limita superioara a procentajului este: " + procent);
	            
            nr_documente = Integer.parseInt(br.readLine());
           // System.out.println("Numarul documentelor de verificat: " + nr_documente);
            
            while ((line=br.readLine())!=null){
            	documente_de_verificat.add(line);
            }
           // System.out.println("Lista documentelor de verificat este: " + documente_de_verificat.toString());
            br.close(); 
        }       
        catch (Exception e){
            System.out.println(e.toString());
        }
        
        WorkPool_Map workpool_map = new WorkPool_Map(NT);
        WorkPool_Reduce workpool_reduce = new WorkPool_Reduce(NT);
        FinalSolution finalsolution = new FinalSolution();
        TaskMap work;
        int p_i = 0;
        int p_f = 0;
    // for(int ii = 0; ii < documente_de_verificat.size(); ii++){
        	 FileInputStream in = null;
             int nrnr = 0;
              try {
                  in = new FileInputStream(documente_de_verificat.get(0));
                
                  int c;

                  while ((c = in.read()) != -1) {
                     nrnr++;
                  }
              } catch (Exception e){
                  System.out.println(e.toString());
              }
              
              //System.out.println("Numrul este: " + nrnr);
              //citesc din fisier cate D octeti(nr_octeti_fragment) si introduc intr-un ArrayList<String>
             ArrayList<String> fragmente_octeti = new ArrayList<String>();
              try{
              FileInputStream f = new FileInputStream(documente_de_verificat.get(0));
           	BufferedInputStream bbb = new BufferedInputStream(f);
      		 int contor = 0;
      		 String buffer = "";
      		
      		 int octeti = nr_octeti_fragment;
      		 
      		 while(contor < nrnr){
      			
      			buffer = "";
      			int inceput = contor;
      			byte[] temp = new byte[octeti];
      			int numbytes = bbb.read(temp);
      			
      			contor+=numbytes;
      			//System.out.println("++++" + temp[0]);
      			byte b=temp[numbytes - 1];
      			
      			//System.out.println("------" + b);
      			byte [] aux = new byte[1];
      			buffer = new String(temp,0,numbytes);
      			//daca  ultimul caracter citit  e litera se citeste pana 
      			//cand se ajunge la un caracter diferite de a-z sau A-Z
      			if((b>='a' && b<='z') || (b>='A'&& b<='Z') || b == '\''){
      				
      				numbytes=bbb.read(aux);
      				contor+=1;
      				b=aux[0];
      				while(((b>='a' && b<='z' ) || (b>='A' && b<='Z') || b == '\''))
      				{
      					buffer+=new String(aux);		
      					
      					if(contor == octeti) break;
      					aux = new byte[1];
      					numbytes=bbb.read(aux);
      					b=aux[0];
      					contor+=1;
      					
      				}
      				 
      			}
      			buffer=buffer.toLowerCase();
      			fragmente_octeti.add(buffer);
      			
      		 }
              }catch (Exception e){
                  System.out.println(e.toString());
              }
           
        	p_i = 0;
        	p_f = 0;
        	
        	while(p_i < fragmente_octeti.size()){
        		
        		work = new TaskMap(fragmente_octeti,p_i,p_f);
        		workpool_map.putWork(work);
        		p_i += 1;
        		p_f += 1;
        	}
        ArrayList<WorkerMap> workers = new ArrayList<WorkerMap>();
        for(int i = 0; i < NT; i++){
        	workers.add(new WorkerMap(workpool_map, workpool_reduce, fragmente_octeti, finalsolution, file_out));
        }
        
       for(int j = 0; j < NT; j++){
        	workers.get(j).start();	
        }

	}
 }
}
