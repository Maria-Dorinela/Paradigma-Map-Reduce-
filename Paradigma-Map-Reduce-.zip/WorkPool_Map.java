import java.util.LinkedList;

/**
 * Clasa ce implementeaza un "work pool" conform modelului "replicated workers".
 * Task-urile introduse in work pool sunt obiecte de tipul TaskMap.
 *
 */
public class WorkPool_Map {
	int nThreads; // nr total de thread-uri worker
	int nWaiting = 0; // nr de thread-uri worker care sunt blocate asteptand un task
	public boolean ready_m = false; // daca s-a terminat complet rezolvarea problemei 
	
	LinkedList<TaskMap> tasks_m;

	/**
	 * Constructor pentru clasa WorkPool.
	 * @param nThreads - numarul de thread-uri worker
	 */
	public WorkPool_Map(int nThreads) {
		this.nThreads = nThreads;
		this.tasks_m = new LinkedList<TaskMap>();
	}

	/**
	 * Functie care incearca obtinera unui task din workpool.
	 * Daca nu sunt task-uri disponibile, functia se blocheaza pana cand 
	 * poate fi furnizat un task sau pana cand rezolvarea problemei este complet
	 * terminata
	 * @return Un task de rezolvat, sau null daca rezolvarea problemei s-a terminat 
	 */
	public synchronized TaskMap getWork() {
		if (tasks_m.size() == 0) { // workpool gol
			nWaiting++;
			/* condtitie de terminare:
			 * nu mai exista nici un task in workpool si nici un worker nu e activ 
			 */
			if (nWaiting == nThreads) {
				ready_m = true;
				/* problema s-a terminat, anunt toti ceilalti workeri */
				notifyAll();
				return null;
			} else {
				while (!ready_m && tasks_m.size() == 0) {
					try {
						this.wait();
					} catch(Exception e) {e.printStackTrace();}
				}
				
				if (ready_m)
				    /* s-a terminat prelucrarea */
				    return null;

				nWaiting--;
				
			}
		}
		//daca rezolvarea problemai s-a terminat returnez null
		if(tasks_m.isEmpty())
			return null;
		//daca rezolvarea problemai nu s-a terminat returnez un task de rezolvat
		else
			return tasks_m.remove();

	}


	/**
	 * Functie care introduce un task in workpool.
	 * @param sp - task-ul care trebuie introdus 
	 */
	synchronized void putWork(TaskMap sp) {
		tasks_m.add(sp);
		/* anuntam unul dintre workerii care asteptau */
		this.notify();

	}


}


