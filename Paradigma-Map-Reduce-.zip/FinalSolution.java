import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;


public class FinalSolution {
	ArrayList<String> fisiere;
	
	ArrayList<FinalSolution> b = new ArrayList<FinalSolution>();
	ArrayList<CuvinteAparitii> w = new ArrayList<CuvinteAparitii>();
	ArrayList<CuvinteAparitii> f_s = new ArrayList<CuvinteAparitii>();
	ArrayList<ArrayList<CuvinteAparitii>> sf = new ArrayList<ArrayList<CuvinteAparitii>>();
	
	/**
	 * constructor implicit
	 */
	public FinalSolution(){
		
	}
	/**
	 * constructor cu parametri
	 * @param word
	 * @param frecventa
	 * @param fisiere
	 * @param frec
	 */
	public FinalSolution(ArrayList<CuvinteAparitii> w ,ArrayList<String> fisiere)
	{
		this.fisiere = fisiere;
		this.w = w;
	}
	
	public void putFinalSolution(ArrayList<FinalSolution> solutie_finala) {
	
		synchronized (Test.o){
			boolean ok = false;
			for(int i = 0; i < solutie_finala.size(); i++){
				ok = false;
				b.add(solutie_finala.get(i));
			}
			f_s.addAll(b.get(b.size()-1).w);
		}
		
		sf.add(f_s);
		System.out.println(sf);
	}
	
	
	public void afisareString(String iesire_finala) {
		String solutie = "";
		double sum = 0;
		
		FileWriter out;
		
		try {
			out = new FileWriter(iesire_finala);
			out.write(solutie);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
