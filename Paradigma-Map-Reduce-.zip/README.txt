Sirbu Maria-Dorinela
332CB
Tema 2

	Pentru rezolvarea temei cu ajutorul modelului MapReduce, am creat doua workPool-uri, unul ce contine task-uri de tipul map iar celalat de tipul reduce. 

	Indexarea unui document se face astfel: Thredul master imparte documentul in fragmente de cate D octeti, (task-uri) pe care le pune intr-un workpool de tipul Map. Se pornesc 
		thred-urile ce vor prelucra fiecare task din acest workpool, transformand-ul intr-un task de tipul Reduce. Aceste task-uri sunt puse la randul lor intr-un workpool de tip Reduce, unde la o repornire a 
		thred-urilor, vor fi prelucrate.
	
	Am creat urmatoarele clase:
	
	Clasa Test.java :
	- contine metoda main() care realizeaza: 
		- in main() impart fisierul in fragmente de cate D octeti si introduc aceste fragmente intr-un ArrayList, dupa care fiecare thread proceseaza cate un element din acest ArrayList
		- citirea din fisierul de intrare, in urma careia se stabilesc: documentul pentru care se doreste determinarea gradului de plagiere
		dimensiunea fragmentelor, pragul de similaritate, numarul ND de documente de indexat
		si numele celor ND documente;
		- in urma impartirii fisierelor de catre Thredul Master, vor rezult atatea task-uri de tip map, cate fragmente de fisiere sunt;
		- adaugarea task-urilor de tip map, in workpool-ul map si pornirea thred-urilor ce prelucreaza aceste task-uri;

	Clasa TaskMap.java:
		- Defineste task-uri de tip Map;
	
	Clasa WorkPoolMap.java:
		- Creaza un workpool ce contine task-uri de tip Map, si defineste metodele:
		-  getWorkMap() : extrage un task din workpool-ul de tip map;
		-  putWorkMap() : adauga un task in workpool-ul de tip map;
	
	Clasa Worker_Map.java:
		- Descrie comportamentul unui worker ce preluceaza un task de tip map, continand urmatoarele metode:
		- processTaskMap : primeste ca parametru un task de tip map, pe care il proceseaza. In urma procesarii va rezulta un task de tipul reduce ce va 
		  fi adaugat in workpool-ul corespunzator (Reduce). In urma procesarii va rezulta un ArrayList cu fiecare cuvant si document si frecventa de aparitie
		  a acestiua in text pentru fiecare fragment.
		- run() : extrage task-uri din workpool-ul Map pe care le proceseaza aplicand functia descrisa mai sus. Dupa terminarea tuturor task-urilor 
		  din workpool, sunt instantiati si porniti workeri de tip Reduce;

	Clasa PartialSolution.java:
		- Defineste task-uri de tip Reduce;
		
	Clasa WorkPool_Reduce.java:
		- Creaza un  workpool ce contine task-uri de tip Reduce, definind metodele:
		-  getWorkReduce() : extrage un task din workpool-ul de tip reduce;
		-  putWorkReduce() : adauga un task in workpool-ul de tip reduce;
		
	Clasa WorkerReduce.java:
		- Descrie comportamentul unui worker ce prelucreaza un task de tip reduce,continand metodele:
		-processPartialSolutionReduce : primeste ca parametru un task de tip reduce, pe care il proceseaza. In urma procesarii va rezulta o variabila de 
			tipul FinalSolution, care reprezinta un ArrayList cu toate cuvintele din document si frecventa de aparitie.
		run() : extrage task-uri din workpool-ul Reduce pe care le proceseaza aplicand functia descrisa mai sus.

	Clasa FinalSolution.java:
		- Realizeaza procesarea vectorilor de solutii rezultati in urma prelucrarii task-urilor din workpool-ul de tip Reduce. Contine metodele:
		- putFinalSolution;
		- afisareString.
		
	Clasa CuvinteAparitii.java:
		-structura ce contine campurile: cuvant, frecventa
	
	Tema este incompleta, cuprinde decat indexarea unui document si afisaza vectorul cu fiecare cuvant si frecventa corespunzatoare din document.
	M-am blocat atunci cand am vrut sa fac indexarea pentru mai multe documente si sa introduc in HashMap. Daca in main() introduceam un for pentru toate documentele nu imi completa
	vectorul bine, incurca cuvintele intre ele din documente.
	Gradul de plagiere il determinam parcurgand elementele din HashMap doua cate doua si aplicarea formulei data in enuntul temei.
	
		
		
		
	
	