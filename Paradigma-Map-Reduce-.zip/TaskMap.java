import java.util.ArrayList;


public class TaskMap {

	public int initial_position = 0; //pozitia de unde incepe sa citeasca din fisier
	public int final_position = 0;//pozitia de sfarsit
	public String nume_fisier;
	ArrayList<String> nume_s = new ArrayList<String>();
	//public int D;
	//ArrayList<String> fragment = new ArrayList<String>();
	
	
	/**
	 * constructor implicit
	 */
	public TaskMap(){
		
	}
	
	/**
	 * constructor cu parametri
	 */
	public TaskMap(ArrayList<String> nume_s, int initial_position, int final_position){
		this.initial_position = initial_position;
		this.final_position = final_position;
		this.nume_s = nume_s;
	}
}
