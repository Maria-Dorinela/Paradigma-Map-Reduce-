import java.util.ArrayList;
import java.util.HashMap;

/**
 * Clasa ce reprezinta o solutie partiala pentru problema de rezolvat. Aceste
 * solutii partiale constituie task-uri care sunt introduse in workpool.
 */
public class PartialSolution {
	HashMap hashmap;// = new HashMap();
	String nume_document = "";
	ArrayList<String> nume_str = new ArrayList<String>();
	ArrayList<CuvinteAparitii> vector_partial;// = new ArrayList<CuvinteAparitii>();

	/**
	 * constructor implicit
	 */
	public PartialSolution(){
		
	}
	
	/**
	 * constructor cu parametri
	 */
	public PartialSolution(HashMap hashmap,String nume_document,ArrayList<CuvinteAparitii> vector_partial, ArrayList<String> nume_str){
		this.nume_document = nume_document;
		this.nume_str = nume_str;
		this.vector_partial = (ArrayList<CuvinteAparitii>) vector_partial.clone();
		hashmap.put(this.nume_document, this.vector_partial);
		this.hashmap = hashmap;
	}
}
