
public class CuvinteAparitii {
	
	public String word;
	double frecventa;//frecventa de aparitie a unui termen document
	
	/**
	 * constructor implicit
	 */
	public CuvinteAparitii() {
		
	}
	
	/**
	 * constructor cu parametri
	 */
	public CuvinteAparitii(String word, double frecventa){
		this.word = word;
		this.frecventa = frecventa;
		//this.nr_aparitii= nr_aparitii;
	}
	
	@Override
	public String toString(){
		return "(" + word + "," + frecventa + ")";
	}
}
