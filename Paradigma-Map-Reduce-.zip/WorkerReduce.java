import java.io.IOException;
import java.util.ArrayList;


public class WorkerReduce extends Thread{
	
	WorkPool_Reduce workpool_reduce;
	FinalSolution final_s;
	ArrayList<String> nume_fisier;
	String iesire_finala;//numele fisierului de iesire
	
	ArrayList<ArrayList<CuvinteAparitii>> frecvente = new ArrayList<ArrayList<CuvinteAparitii>>();
	
	ArrayList<FinalSolution> solutie_finala = new ArrayList<FinalSolution>();
	ArrayList<CuvinteAparitii> cuvant1 = new ArrayList<CuvinteAparitii>();
	FinalSolution sf = new FinalSolution();
	/**
	 * constructor implicit
	 */
	public WorkerReduce(){
		
	}
	
	/**
	 * constructor cu parametri
	 */
	public WorkerReduce(WorkPool_Reduce workpool_reduce,FinalSolution final_s,ArrayList<String> nume_fisier,String iesire_finala){
		this.workpool_reduce = workpool_reduce;
		this.final_s = final_s;
		this.nume_fisier = nume_fisier;
		this.iesire_finala = iesire_finala;
	}
	
	ArrayList<CuvinteAparitii> ajutor(PartialSolution ps){
		ArrayList<CuvinteAparitii> aux = new ArrayList<CuvinteAparitii>();
		
		
		return aux;
	}
	
	void processPartialSolution(PartialSolution ps){
		
		FinalSolution f = new FinalSolution();
		boolean ok = false;
		String cuva = "";
		double frecv = 0;
		
		
		
		for(int i = 0; i < nume_fisier.size(); i++){
			frecvente.add(i, new ArrayList<CuvinteAparitii>());
		}
		
		ArrayList<CuvinteAparitii> auxiliar = new ArrayList<CuvinteAparitii>();
		
		ArrayList<CuvinteAparitii> cuvant = new ArrayList<CuvinteAparitii>();
			boolean adaugat = false;
			for(int i1 = 2; i1 < ps.vector_partial.size(); i1++){
			
				adaugat = false;
				for(int i2 = 0; i2 < sf.w.size(); i2++){
					if(ps.vector_partial.get(i1).word.equals(sf.w.get(i2).word)){
						sf.w.get(i2).frecventa += ps.vector_partial.get(i1).frecventa;
						adaugat  = true;
						break;
					}
				}
				if (adaugat == false){
					sf.w.add(new CuvinteAparitii(ps.vector_partial.get(i1).word, ps.vector_partial.get(i1).frecventa));
				
				}
				for(int j = 0; j < nume_fisier.size(); j++){
					if(nume_fisier.get(j).equals(ps.nume_document)){
						sf.w.add(ps.vector_partial.get(i1));
					}
				}
			}
			//System.out.println(sf.w.size());
			f = new FinalSolution(sf.w, nume_fisier);
			solutie_finala.add(f);
		
	}
	

	public void run(){
		while (true) {
			
			PartialSolution ps = workpool_reduce.getWork();
			
			if (ps == null){
				final_s.putFinalSolution(solutie_finala);
				break;
			}
			else
			processPartialSolution(ps);
		}
		
		synchronized (Test.o){
			//System.out.println("Rezultat");
			final_s.afisareString(iesire_finala);
		}
	}
}
